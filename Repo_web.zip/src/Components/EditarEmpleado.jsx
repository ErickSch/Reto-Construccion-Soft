


export default function EditarEmpleado() {
    
    return (
        <div className="">
            <p>
                Pagina para editar empleados
            </p>
        </div>
    )
}

