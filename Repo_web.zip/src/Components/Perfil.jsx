export default function Perfil() {
    return(
        <div>Perfil</div>
    )
}