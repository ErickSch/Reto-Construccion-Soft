export default function Puntuaciones() {
    return(
        <div>Puntuaciones</div>
    )
}