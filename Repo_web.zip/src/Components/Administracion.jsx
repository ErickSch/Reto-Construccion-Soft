import TablaABC from "./TablaABC";


export default function Administracion() {
    // hacer una tabla que de funcionalidad CRUD hacia los empleados
    return (
        <TablaABC/>
    )
}

