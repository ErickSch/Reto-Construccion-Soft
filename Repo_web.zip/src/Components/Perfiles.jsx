export default function Perfiles() {
    return(
        <div>Perfiles</div>
    )
}